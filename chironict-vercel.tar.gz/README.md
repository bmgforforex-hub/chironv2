# Chironict - ICT/SMC Elite Bilgi Motoru (Vercel)

## 🚀 Kurulum Adımları (5 Dakika!)

### Adım 1: Groq API Key Alın (ÜCRETSİZ - 2 dakika)

1. https://console.groq.com adresine gidin
2. **Sign Up** tıklayın (Google ile giriş yapabilirsiniz)
3. Sol menüden **"API Keys"** tıklayın
4. **"Create API Key"** butonuna tıklayın
5. İsim verin (örn: "chironict") ve **Create** tıklayın
6. Oluşan key'i **KOPYALAYIN** (örn: `gsk_...`)
   ⚠️ Bu key'i bir yere not edin, bir daha göremezsiniz!

---

### Adım 2: GitHub'a Yükleyin (1 dakika)

1. GitHub'da **yeni repo** oluşturun (örn: "chironict")
2. Bu klasördeki **TÜM dosyaları** repo'ya yükleyin:
   - `index.html`
   - `vercel.json`
   - `package.json`
   - `api/chat.js`

**ÖNEMLİ:** Dosya yapısı şöyle olmalı:
```
chironict/
├── index.html
├── vercel.json
├── package.json
└── api/
    └── chat.js
```

---

### Adım 3: Vercel'e Deploy Edin (1 dakika)

1. https://vercel.com adresine gidin
2. **"Add New"** → **"Project"** tıklayın
3. GitHub repo'nuzu seçin
4. **"Deploy"** butonuna tıklayın (ayar değiştirmeyin)
5. Deploy bitsin (1-2 dakika)

---

### Adım 4: API Key'i Vercel'e Ekleyin (1 dakika)

1. Vercel dashboard'da **projenize** tıklayın
2. Üst menüden **"Settings"** tıklayın
3. Sol menüden **"Environment Variables"** tıklayın
4. **"Add New"** butonuna tıklayın
5. İki alan doldurun:
   - **Name:** `GROQ_API_KEY`
   - **Value:** (Adım 1'de kopyaladığınız key'i yapıştırın)
6. **"Save"** tıklayın
7. Üstte **"Redeploy"** butonuna tıklayın (site yeniden deploy olacak)

---

### Adım 5: Test Edin! 🎉

1. Vercel size bir link vermiş (örn: `chironict.vercel.app`)
2. Bu linke gidin
3. Bir ICT sorusu sorun (örn: "Fair Value Gap nedir?")
4. Cevap gelirse **BAŞARILI!** 🚀

---

## 🔧 Sorun Giderme

### "404 Not Found" alıyorum
- `index.html` dosyası repo'nun **ana dizininde** olmalı (klasör içinde değil)
- GitHub repo'yu kontrol edin

### "API Error" alıyorum
- Environment Variable doğru mu? `GROQ_API_KEY` (tam bu şekilde yazılmalı)
- Redeploy yaptınız mı?
- Groq API key'i geçerli mi? (console.groq.com'dan kontrol edin)

### Yanıt gelmiyor
- Vercel deploy tamamlandı mı? (Deployments sekmesinden kontrol edin)
- 2-3 dakika bekleyin ve sayfayı yenileyin

---

## 💰 Maliyet

- **Groq API:** Tamamen ücretsiz (günde 14,400 istek)
- **Vercel Hosting:** Tamamen ücretsiz
- **Toplam:** 0₺ 🎉

---

## 📊 Teknik Detaylar

- **Frontend:** Vanilla JS, CSS
- **Backend:** Vercel Serverless Functions
- **AI Model:** Llama 3.1 70B (Groq)
- **Yanıt Süresi:** 1-2 saniye
- **Günlük Limit:** 14,400 istek (100-200 kullanıcı rahat kullanır)

---

## ✨ Özellikler

- ✅ Kullanıcı hiçbir şey yapmaz, direkt soru sorar
- ✅ Prompt'unuza %100 sadık (10 bölümlü format)
- ✅ Tamamen Türkçe
- ✅ Hızlı yanıt (1-2 saniye)
- ✅ Mobil uyumlu
- ✅ Modern tasarım

---

## 🎯 Site Adını Değiştirme (Opsiyonel)

Vercel size rastgele isim verir (örn: `chironict-abc123.vercel.app`)

**Özel isim için:**
1. Vercel → Settings → Domains
2. "chironict.vercel.app" gibi bir isim ekleyin
3. Ya da custom domain ekleyin (chironict.io)

---

## ❓ Yardım

Takıldığınız yer olursa, bu README'yi dikkatlice okuyun.
Her adım test edilmiş ve çalışıyor! 💪
